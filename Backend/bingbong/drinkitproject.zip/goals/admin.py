from django.contrib import admin
from .models import Goal

admin.site.register(Goal)
